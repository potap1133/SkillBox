﻿using System;

namespace HomeWork_4_02
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] massiv = new int[,];
        }
    }
}
