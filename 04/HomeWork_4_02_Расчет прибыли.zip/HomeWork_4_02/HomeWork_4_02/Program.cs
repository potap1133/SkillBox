﻿using System;

namespace HomeWork_4_02
{
    class Program
    {
        /// <summary>
        /// Вход в программу по расчету прибыльных месяцев и убыточных
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Random randomiz = new Random();                   // Генератор псевдо случайеых чисел
            
            var monthNumber = 1;                              // Инициализация переменных
            var randomNumber = 0;
            var threeSmallerProfits = 0;
            var numberOfMonthsWithAPositiveProfit = 0;

            int[] month = new int[13];                        // Создание массивов 

            int[] incomeOfMonthMassiv = new int[13];

            int[] expensesOfMonthMassiv = new int[13];

            int[] profitOfMonthMassiv = new int[13];

            int[] profitOfMonthMassivSecond = new int[13];

            Console.WriteLine(" {0,1} {1,5} {2,5} {3,5} "  , "Месяц",                // Вывод оглавлений столбцов
                                                             " Доход, тыс. руб. ",
                                                             " Расход, тыс. руб. ",
                                                           " Прибыль, тыс. руб.");

            for (int i = 1; i < 13; i++)                      // Цикл в котором массивы получают рандомные значени
            {
                month[i] = i;                                 // Массив номерации месяцев

                randomNumber = randomiz.Next(1000, 1_000_000);// Выбор диапазона случайных чисел
                incomeOfMonthMassiv[i] = randomNumber;        // Присваивание переменной случайных значений

                randomNumber = randomiz.Next(1000, 1_000_000); // Выбор диапазона случайных чисел
                expensesOfMonthMassiv[i] = randomNumber;       // Присваивание переменной случайных значений

                profitOfMonthMassiv[i] = incomeOfMonthMassiv[i] - expensesOfMonthMassiv[i]; //Вычисление прибыли

                Console.WriteLine($"{month[i],6} " +           // Вывод на в консоль заполненых данными массивов
                                  $"{incomeOfMonthMassiv[i],16:### ###} " +
                                  $"{expensesOfMonthMassiv[i],19:### ###} " +
                                  $"{profitOfMonthMassiv[i],20:### ###} ");
                
               
            }

            for (int j = 0; j < 12; j++)                      // Вычисление прибыли для выделения 3-ех наименьших
            {
                profitOfMonthMassivSecond[j] = incomeOfMonthMassiv[j] - expensesOfMonthMassiv[j];
            }

            Array.Sort(profitOfMonthMassivSecond);            // Сортировка массива прибыли 

            Console.Write($"\n\n Худщая прибыль в месяцах : "); // Вывыод текста

            for (int j = 0; j < 3; j++)                      // Цикл отбор 3-ех. наименьших значений 
            {
                threeSmallerProfits = profitOfMonthMassivSecond[j];// Присваивание переменной 3-ех. наименьших значений

                for (int i = 1; i < 13; i++)                 // Цикл выбора наименьших значений из всех знач. прибыли
                {
                    if (profitOfMonthMassivSecond[j] == profitOfMonthMassiv[i]) // Условие выбора
                    {
                        Console.Write($" {i},");             // Вывод индекса месяцев с наименьшим показателем прибыли
                        
                    }
                }
            }

            Console.WriteLine();                             // Пустая строка
            
            for (int i = 1; i < 13; i++)                     // Цикл подсчета месяцев с положительной прибылью
            {
                if (profitOfMonthMassiv[i] > 0)              // Условие вычисления положительной прибыли
                {
                    numberOfMonthsWithAPositiveProfit++;     // Счетчик месяцев с положительной прибылью 

                }
            }
            // Вывод кол-ва месяцев с положительной прибылью
            Console.Write($" Количество месяцев с положительной тприбылью : {numberOfMonthsWithAPositiveProfit}");

            Console.ReadKey();
        }
    }
}
